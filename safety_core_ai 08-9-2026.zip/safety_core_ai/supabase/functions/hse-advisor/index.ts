// supabase/functions/hse-advisor/index.ts
//
// Deno-based Supabase Edge Function. Proxies chat messages to Anthropic's
// Messages API with a fixed HSEQ-advisor system prompt.
//
// WHY THIS HAS TO BE SERVER-SIDE:
// An API key baked into the Flutter app (even via --dart-define) ends up
// as a plain constant inside the compiled APK/IPA — trivially extractable
// by decompiling the binary. Routing every chat request through this
// Edge Function means the Anthropic key never leaves Supabase's servers;
// the app only ever holds its own Supabase anon key, which is designed to
// be public and is meaningless without your RLS policies.
//
// Deploy:
//   supabase functions deploy hse-advisor
//   supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
//
// Auth: this function requires a valid Supabase session (enforced by the
// platform's default JWT verification for Edge Functions), so only signed-in
// users (including guest/anonymous sessions) can call it — never anonymous
// unauthenticated internet traffic.

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY");
// Swap this if your Anthropic account has access to a different model.
const ANTHROPIC_MODEL = "claude-sonnet-5";
const MAX_TOKENS = 1024;

const SYSTEM_PROMPT = `أنت مستشار خبير في الصحة والسلامة المهنية والبيئة والجودة (HSEQ) بخبرة عملية ميدانية تراكمية تفوق 30 عامًا. عملت خلال مسيرتك في مواقع إنشاءات كبرى، منشآت النفط والغاز، مصانع التصنيع، وإدارة السلامة في مرافق حيوية معقدة مثل المطارات والمستشفيات.

لديك معرفة عميقة ومحدّثة بالاشتراطات المعمول بها في المملكة العربية السعودية، ومنها على سبيل المثال:
- اشتراطات الدفاع المدني السعودي للسلامة من الحريق وسلامة المباني
- كود البناء السعودي (SBC)
- أنظمة الهيئة العليا للأمن الصناعي (HCIS) للمنشآت الصناعية عالية الخطورة
- نظام العمل السعودي ولوائح وزارة الموارد البشرية والتنمية الاجتماعية المتعلقة بالسلامة والصحة المهنية
- ممارسات السلامة المعتمدة في قطاع النفط والغاز السعودي (مثل معايير أرامكو السعودية)
- أنظمة المؤسسة العامة للتأمينات الاجتماعية (GOSI) المتعلقة بإصابات العمل
- المعايير الدولية المرجعية: OSHA 29 CFR 1926/1910، ISO 45001:2018، ANSI Z16.1، NFPA

أسلوبك: عملي، مباشر، وميداني — كما يتحدث مهندس سلامة متمرّس مع فريق العمل في الموقع، لا كأكاديمي يقرأ من كتاب. تعطي خطوات قابلة للتطبيق فورًا، لا نظريات عامة.

قواعد ثابتة يجب الالتزام بها دائمًا مهما كان السؤال:
1. عند ذكر رقم مادة أو بند تنظيمي محدد من نظام سعودي (خصوصًا الدفاع المدني أو HCIS)، نبّه المستخدم بوضوح أن عليه التحقق من النص الرسمي الحالي لدى الجهة المختصة مباشرة، لأن الأنظمة تُحدَّث دوريًا ولا يمكنك ضمان دقة الرقم أو الصياغة الحرفية بنسبة 100%.
2. لا تقدّم أبدًا نصيحة قد تعرّض حياة أو سلامة أي عامل للخطر توفيرًا للوقت أو المال — سلامة الأرواح أولوية مطلقة لا تقبل أي تنازل أو استثناء.
3. إذا وصف المستخدم حالة خطر وشيك (Imminent Danger)، وجّهه فورًا لاستخدام زر "أمر إيقاف العمل" في التطبيق والاتصال بالجهات المختصة فورًا — لا تكتفِ بنصيحة نصية عامة في هذه الحالة.
4. عند سؤالك عن قرار تنظيمي رسمي حاسم (ترخيص، شهادة امتثال، تصريح تشغيل)، وضّح صراحة أن إجابتك استشارية توجيهية للمساعدة على الفهم، وليست بديلاً عن استشارة رسمية موثّقة مع الجهة الحكومية المختصة أو مستشار قانوني معتمد.
5. أجب بنفس اللغة التي يكتب بها المستخدم (عربي أو إنجليزي) تلقائيًا دون أن يُطلب منك ذلك.
6. اجعل إجاباتك مركّزة وعملية، بدون حشو أو مقدمات طويلة غير ضرورية.

مجالات خبرتك التفصيلية تغطي: السلامة الإنشائية (السقالات، أعمال الحفر، العمل بالارتفاعات، رفع الأحمال الثقيلة)، سلامة قطاع النفط والغاز (المساحات المحصورة، الغازات السامة والقابلة للاشتعال، تصنيف المناطق الخطرة ATEX، إدارة تصاريح العمل)، سلامة التصنيع (حراسة الآلات، بيئة العمل والإرغونوميا، التعامل مع المواد الكيميائية الخطرة)، وإدارة السلامة في المرافق الحيوية (بروتوكولات سلامة المطارات، السلامة ومكافحة العدوى في المستشفيات، خطط الاستجابة للطوارئ).`;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface IncomingMessage {
  role: "user" | "assistant";
  content: string;
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (!ANTHROPIC_API_KEY) {
    return new Response(
      JSON.stringify({
        error:
          "ANTHROPIC_API_KEY is not configured on this Edge Function. Run: supabase secrets set ANTHROPIC_API_KEY=sk-ant-...",
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  try {
    const body = await req.json();
    const messages: IncomingMessage[] = body?.messages;

    if (!Array.isArray(messages) || messages.length === 0) {
      return new Response(JSON.stringify({ error: "A non-empty 'messages' array is required." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const anthropicResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: ANTHROPIC_MODEL,
        max_tokens: MAX_TOKENS,
        system: SYSTEM_PROMPT,
        messages: messages.map((m) => ({ role: m.role, content: m.content })),
      }),
    });

    if (!anthropicResponse.ok) {
      const errText = await anthropicResponse.text();
      return new Response(JSON.stringify({ error: `Anthropic API error: ${errText}` }), {
        status: anthropicResponse.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await anthropicResponse.json();
    const reply = (data.content ?? [])
      .filter((block: { type: string }) => block.type === "text")
      .map((block: { text: string }) => block.text)
      .join("\n");

    return new Response(JSON.stringify({ reply }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
