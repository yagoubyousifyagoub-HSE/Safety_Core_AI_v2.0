import 'package:supabase_flutter/supabase_flutter.dart';
import 'models/chat_message.dart';

/// Calls the `hse-advisor` Supabase Edge Function — never talks to
/// Anthropic directly. The API key lives only on the Edge Function side
/// (see supabase/functions/hse-advisor/index.ts); this client only ever
/// holds the already-public Supabase anon key.
class HseChatService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<String> sendMessage(List<ChatMessage> history) async {
    final payload = {
      'messages': history
          .map((m) => {
                'role': m.role == ChatRole.user ? 'user' : 'assistant',
                'content': m.content,
              })
          .toList(),
    };

    final response = await _client.functions.invoke('hse-advisor', body: payload);

    final data = response.data;
    if (data is Map && data['error'] != null) {
      throw Exception(data['error'].toString());
    }
    if (data is Map && data['reply'] is String) {
      return data['reply'] as String;
    }
    throw Exception('Unexpected response from the HSE advisor function: $data');
  }
}
