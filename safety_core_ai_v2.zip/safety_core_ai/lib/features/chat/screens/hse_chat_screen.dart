import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../l10n/gen/app_localizations.dart';
import '../hse_chat_service.dart';
import '../models/chat_message.dart';

class HseChatScreen extends StatefulWidget {
  final bool isLocalDemo;
  const HseChatScreen({super.key, this.isLocalDemo = false});

  @override
  State<HseChatScreen> createState() => _HseChatScreenState();
}

class _HseChatScreenState extends State<HseChatScreen> {
  final _service = HseChatService();
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _isSending = false;
  String? _error;

  Future<void> _send([String? presetText]) async {
    final text = (presetText ?? _inputCtrl.text).trim();
    if (text.isEmpty || _isSending) return;

    final l10n = AppLocalizations.of(context)!;
    setState(() {
      _messages.add(ChatMessage(role: ChatRole.user, content: text, timestamp: DateTime.now()));
      _inputCtrl.clear();
      _isSending = true;
      _error = null;
    });
    _scrollToBottom();

    try {
      final reply = await _service.sendMessage(_messages);
      if (!mounted) return;
      setState(() {
        _messages.add(ChatMessage(role: ChatRole.assistant, content: reply, timestamp: DateTime.now()));
      });
      _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = '${l10n.chatFailed}\n$e');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text(l10n.chatTab)),
      body: widget.isLocalDemo ? _buildLocalDemoNotice(l10n) : _buildChat(l10n),
    );
  }

  Widget _buildLocalDemoNotice(AppLocalizations l10n) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_outlined, size: 44, color: AppColors.slate500),
            const SizedBox(height: 16),
            Text(
              l10n.chatUnavailableLocalDemo,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.slate500),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChat(AppLocalizations l10n) {
    return Column(
      children: [
        Expanded(
          child: _messages.isEmpty
              ? _EmptyState(onSuggestionTap: _send)
              : ListView.builder(
                  controller: _scrollCtrl,
                  padding: const EdgeInsets.all(16),
                  itemCount: _messages.length + (_isSending ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == _messages.length) {
                      return const _TypingIndicator();
                    }
                    return _MessageBubble(message: _messages[index]);
                  },
                ),
        ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(_error!, style: const TextStyle(color: AppColors.statusOpen, fontSize: 12)),
          ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _inputCtrl,
                    minLines: 1,
                    maxLines: 4,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _send(),
                    decoration: InputDecoration(
                      hintText: l10n.chatInputHint,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: _isSending ? null : () => _send(),
                  icon: const Icon(Icons.send_rounded),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final ChatMessage message;
  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == ChatRole.user;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Align(
        alignment: isUser ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: isUser ? AppColors.accent.withOpacity(0.18) : AppColors.slate800,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: isUser ? AppColors.accent.withOpacity(0.4) : AppColors.slate700),
          ),
          child: Text(message.content, style: const TextStyle(color: AppColors.slate200, height: 1.4)),
        ),
      ),
    );
  }
}

class _TypingIndicator extends StatelessWidget {
  const _TypingIndicator();

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional.centerStart,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.slate800,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.slate700),
        ),
        child: const SizedBox(
          height: 14,
          width: 14,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final ValueChanged<String> onSuggestionTap;
  const _EmptyState({required this.onSuggestionTap});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final suggestions = [l10n.chatSuggestion1, l10n.chatSuggestion2, l10n.chatSuggestion3];

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.support_agent_outlined, size: 48, color: AppColors.accent),
            const SizedBox(height: 14),
            Text(
              l10n.chatEmptyTitle,
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Text(
              l10n.chatEmptySubtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.slate500, fontSize: 12),
            ),
            const SizedBox(height: 20),
            ...suggestions.map(
              (s) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: OutlinedButton(
                  onPressed: () => onSuggestionTap(s),
                  child: Text(s, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
