-- Fix: "infinite recursion detected in policy for relation 'profiles'"
-- (Postgres error 42P17)
--
-- Root cause: the "profiles: consultants/admins read all" policy is
-- defined ON public.profiles, but its USING clause queries
-- public.profiles again to check the caller's role. Evaluating that
-- policy therefore requires re-evaluating that same policy, forever.
--
-- Fix: move the role lookup into a SECURITY DEFINER function. Because the
-- function runs with the privileges of its owner (not the calling user),
-- the SELECT inside it bypasses RLS entirely instead of re-triggering the
-- policy — breaking the loop. This is the standard, Supabase-documented
-- pattern for this exact error.
--
-- Safe to run multiple times and safe to run on a project that already
-- has the old (broken) policies — every statement below is idempotent.

create or replace function public.current_user_role()
returns text
language sql
security definer
stable
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

-- Re-create the previously-recursive policy using the helper function.
drop policy if exists "profiles: consultants/admins read all" on public.profiles;
create policy "profiles: consultants/admins read all"
  on public.profiles for select
  using (public.current_user_role() in ('consultant', 'admin'));

-- These weren't the direct cause of the recursion (they're policies on
-- other tables, not on profiles itself), but they used the same repeated
-- subquery pattern — switched to the helper function too, for a single
-- source of truth going forward.
drop policy if exists "project_boundaries: only consultants/admins write" on public.project_boundaries;
create policy "project_boundaries: only consultants/admins write"
  on public.project_boundaries for all
  using (public.current_user_role() in ('consultant', 'admin'));

drop policy if exists "observations: consultants/admins full access" on public.observations;
create policy "observations: consultants/admins full access"
  on public.observations for all
  using (public.current_user_role() in ('consultant', 'admin'));

drop policy if exists "observations: guests read demo project only" on public.observations;
create policy "observations: guests read demo project only"
  on public.observations for select
  using (
    public.current_user_role() = 'guest'
    and project_name = 'Demo Site — Sandbox'
  );

drop policy if exists "observations: guests insert into demo project only" on public.observations;
create policy "observations: guests insert into demo project only"
  on public.observations for insert
  with check (
    public.current_user_role() = 'guest'
    and created_by = auth.uid()
    and project_name = 'Demo Site — Sandbox'
  );

drop policy if exists "observations: guests update own demo submissions" on public.observations;
create policy "observations: guests update own demo submissions"
  on public.observations for update
  using (
    public.current_user_role() = 'guest'
    and created_by = auth.uid()
    and project_name = 'Demo Site — Sandbox'
  )
  with check (project_name = 'Demo Site — Sandbox');
