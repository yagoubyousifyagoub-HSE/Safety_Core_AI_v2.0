class AppConstants {
  AppConstants._();

  /// Every guest-authored observation is sandboxed server-side to this
  /// project name (see the "guests sandboxed to demo project" RLS policies
  /// in supabase/schema.sql). Keep this string identical to the SQL — a
  /// mismatch silently breaks guest submissions (RLS rejects the insert).
  static const String demoProjectName = 'Demo Site — Sandbox';

  /// Placeholder "user id" for observations created in Local Demo Mode
  /// (see local_demo_data.dart) — this mode never touches Supabase Auth,
  /// so there is no real signed-in user id to attach.
  static const String localDemoUserId = 'local-demo-device-user';

  /// Must match Supabase's Authentication -> Sign In / Providers -> Email
  /// -> OTP Length setting. Supabase's default has shifted between 6 and 8
  /// digits depending on when a project was provisioned — if OTP
  /// verification starts failing after matching the code you see in your
  /// inbox, check that setting first and update this constant to match
  /// (or change the Supabase setting to 6 to match this default).
  static const int otpCodeLength = 6;
}
